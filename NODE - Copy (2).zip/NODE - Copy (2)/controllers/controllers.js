const FEED = require('../modules/Posts' )


const gethomepage = (req,res)=> {
    FEED.find().sort({createdAt: -1})
       .then((result)=>{res.render('index', {Posts: result})
       console.log(result)})  
       .catch((err) => console.log(err))}


const getNewFeed =(req, res)=>{ 
    FEED.find()
       .then(()=>res.render('addNewpost'))  
       .catch((err) => console.log(err))}


const addpost =(req, res)=>

{ console.log(req.body)
    const feed= new FEED(req.body)
    feed.save()
    .then(()=>res.redirect('/'))  
    .catch((err) => console.log(err))}

        
const  showOne =   (req, res)=>{ 
    console.log(typeof req.params)
    FEED.findOne({_id:req.params.id}).sort({createdAt: -1})
       .then((result)=> res.render('showOne', {result}))
       .catch((err) => console.log(err))}

const DeletePost= (req,res)=>{
    FEED.findByIdAndDelete(req.params.id)
        .then(result=>{
            res.redirect('/')
        })
        .catch(err => console.log(err))
    }
       
 const  updateView=(req,res)=>{
        const id = req.params.id
        FEED.findByIdAndUpdate(id,{name:req.body.name, text:req.body.txt})
        .then(()=>{
            res.redirect('/')
        })
        .catch((err)=>{
            console.log(err)
        })
    }
       



module.exports={
    gethomepage,
    getNewFeed,
    addpost,
    showOne,
    DeletePost,
    updateView,
}