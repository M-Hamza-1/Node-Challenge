const mongoose = require('mongoose')


const  db = 'mongodb+srv://brocklesnare:Aa123456789@challenge.tdbztnn.mongodb.net/Abood?retryWrites=true&w=majority&appName=challenge'

mongoose.connect(db)
   .then(result=> console.log('connected to db'))
   .catch(err=> console.log(err))
