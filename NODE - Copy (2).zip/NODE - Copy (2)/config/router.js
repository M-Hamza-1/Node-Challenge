const express = require('express')
const controllers = require('../controllers/controllers')
const router = express.Router()



router.get('/',  controllers.gethomepage)
router.get('/add-post',  controllers.getNewFeed)
router.post('/add-post',  controllers.addpost)

router.get('/post/:id',  controllers.showOne)

router.post('/delete/:id',controllers.DeletePost)
router.post("/edit/post/:id",controllers.updateView)













module.exports = router